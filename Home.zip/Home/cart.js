let all = document.querySelector(".all")
let main = document.querySelector(".main")
let a1 = document.querySelector(".a1")
let a2 = document.querySelector(".a2")
let total2 = document.querySelector(".total2")
let a3 = document.querySelector(".a3")

all.style.backgroundColor = "blueviolet"
all.style.marginBottom = "-130px"
all.style.width = "100%"
all.style.height = "740px"

main.style.display = "flex"

a1.style.paddingLeft = "50px"
a1.style.paddingRight = "15px"
a1.style.paddingTop = "50px"
a1.style.backgroundColor = "yellow"
a1.style.fontSize = "100px"
a1.style.fontFamily = " Arial, Helvetica, sans-serif"

a2.style.marginLeft = "110px"
a2.style.marginTop = "50px"
a2.style.color = "white"
a2.style.fontSize = "90px"
a2.style.fontWeight= "900px"
a2.style.fontFamily = " Arial, Helvetica, sans-serif"

total2.style.display = "flex"

a3.style.color = "rgb(215, 215, 215)"
a3.style.marginLeft = "110px"
a3.style.marginTop = "220px"
a3.style.fontSize = "70px"
a3.style.width = "40px"